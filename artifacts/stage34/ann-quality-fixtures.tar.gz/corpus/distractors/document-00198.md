# Evaluation item 00198
Synthetic benchmark source record number 00198.
