# Evaluation item 00341
Synthetic benchmark source record number 00341.
