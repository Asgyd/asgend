# Evaluation item 00423
Synthetic benchmark source record number 00423.
