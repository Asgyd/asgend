# Evaluation item 00048
Synthetic benchmark source record number 00048.
