# Evaluation item 00344
Synthetic benchmark source record number 00344.
