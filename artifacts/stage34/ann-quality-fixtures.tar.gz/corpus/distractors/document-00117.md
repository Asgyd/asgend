# Evaluation item 00117
Synthetic benchmark source record number 00117.
