# Evaluation item 00246
Synthetic benchmark source record number 00246.
