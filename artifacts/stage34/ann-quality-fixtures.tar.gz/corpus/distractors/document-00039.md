# Evaluation item 00039
Synthetic benchmark source record number 00039.
