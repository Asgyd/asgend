# Evaluation item 00234
Synthetic benchmark source record number 00234.
