# Evaluation item 00122
Synthetic benchmark source record number 00122.
