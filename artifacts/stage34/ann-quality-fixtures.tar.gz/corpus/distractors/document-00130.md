# Evaluation item 00130
Synthetic benchmark source record number 00130.
