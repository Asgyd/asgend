# Evaluation item 00493
Synthetic benchmark source record number 00493.
