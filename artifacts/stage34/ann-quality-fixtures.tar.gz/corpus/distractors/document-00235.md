# Evaluation item 00235
Synthetic benchmark source record number 00235.
