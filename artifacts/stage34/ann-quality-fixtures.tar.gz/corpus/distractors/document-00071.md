# Evaluation item 00071
Synthetic benchmark source record number 00071.
