# Evaluation item 00172
Synthetic benchmark source record number 00172.
