# Evaluation item 00125
Synthetic benchmark source record number 00125.
