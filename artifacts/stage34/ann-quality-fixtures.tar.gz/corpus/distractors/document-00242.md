# Evaluation item 00242
Synthetic benchmark source record number 00242.
