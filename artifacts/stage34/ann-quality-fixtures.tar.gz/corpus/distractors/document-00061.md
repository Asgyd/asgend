# Evaluation item 00061
Synthetic benchmark source record number 00061.
