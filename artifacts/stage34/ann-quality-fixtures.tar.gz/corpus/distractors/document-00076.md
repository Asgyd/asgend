# Evaluation item 00076
Synthetic benchmark source record number 00076.
