# Evaluation item 00470
Synthetic benchmark source record number 00470.
