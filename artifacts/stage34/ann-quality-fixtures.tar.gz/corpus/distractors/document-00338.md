# Evaluation item 00338
Synthetic benchmark source record number 00338.
