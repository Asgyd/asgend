# Evaluation item 00170
Synthetic benchmark source record number 00170.
