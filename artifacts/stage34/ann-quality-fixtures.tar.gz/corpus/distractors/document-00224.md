# Evaluation item 00224
Synthetic benchmark source record number 00224.
