# Evaluation item 00097
Synthetic benchmark source record number 00097.
