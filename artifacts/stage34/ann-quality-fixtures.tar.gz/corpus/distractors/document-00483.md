# Evaluation item 00483
Synthetic benchmark source record number 00483.
