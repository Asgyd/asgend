# Evaluation item 00082
Synthetic benchmark source record number 00082.
