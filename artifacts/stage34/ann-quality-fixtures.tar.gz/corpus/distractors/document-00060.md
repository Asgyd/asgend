# Evaluation item 00060
Synthetic benchmark source record number 00060.
