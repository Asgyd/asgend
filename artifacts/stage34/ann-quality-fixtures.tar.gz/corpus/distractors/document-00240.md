# Evaluation item 00240
Synthetic benchmark source record number 00240.
