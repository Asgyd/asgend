# Evaluation item 00306
Synthetic benchmark source record number 00306.
