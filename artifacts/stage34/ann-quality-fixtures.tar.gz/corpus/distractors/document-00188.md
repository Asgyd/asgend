# Evaluation item 00188
Synthetic benchmark source record number 00188.
