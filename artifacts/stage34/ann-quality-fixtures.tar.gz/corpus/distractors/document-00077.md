# Evaluation item 00077
Synthetic benchmark source record number 00077.
