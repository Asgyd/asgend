# Evaluation item 00477
Synthetic benchmark source record number 00477.
