# Evaluation item 00388
Synthetic benchmark source record number 00388.
