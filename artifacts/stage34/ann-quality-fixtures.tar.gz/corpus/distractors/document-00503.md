# Evaluation item 00503
Synthetic benchmark source record number 00503.
