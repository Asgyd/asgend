# Evaluation item 00233
Synthetic benchmark source record number 00233.
