# Evaluation item 00473
Synthetic benchmark source record number 00473.
