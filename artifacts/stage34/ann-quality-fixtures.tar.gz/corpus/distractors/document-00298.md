# Evaluation item 00298
Synthetic benchmark source record number 00298.
