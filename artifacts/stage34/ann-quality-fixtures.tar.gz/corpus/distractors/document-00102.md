# Evaluation item 00102
Synthetic benchmark source record number 00102.
