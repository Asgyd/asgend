# Evaluation item 00043
Synthetic benchmark source record number 00043.
