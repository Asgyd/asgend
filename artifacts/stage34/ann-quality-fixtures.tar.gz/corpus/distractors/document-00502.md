# Evaluation item 00502
Synthetic benchmark source record number 00502.
