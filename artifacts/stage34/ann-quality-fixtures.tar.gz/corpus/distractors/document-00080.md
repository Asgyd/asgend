# Evaluation item 00080
Synthetic benchmark source record number 00080.
