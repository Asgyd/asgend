# Evaluation item 00294
Synthetic benchmark source record number 00294.
