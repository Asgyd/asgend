# Evaluation item 00059
Synthetic benchmark source record number 00059.
