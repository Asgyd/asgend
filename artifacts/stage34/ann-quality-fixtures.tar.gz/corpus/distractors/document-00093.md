# Evaluation item 00093
Synthetic benchmark source record number 00093.
