# Evaluation item 00343
Synthetic benchmark source record number 00343.
