# Evaluation item 00524
Synthetic benchmark source record number 00524.
