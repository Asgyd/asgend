# Evaluation item 00478
Synthetic benchmark source record number 00478.
