# Evaluation item 00053
Synthetic benchmark source record number 00053.
