# Evaluation item 00506
Synthetic benchmark source record number 00506.
