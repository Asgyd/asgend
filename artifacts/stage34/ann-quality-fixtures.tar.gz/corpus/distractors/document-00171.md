# Evaluation item 00171
Synthetic benchmark source record number 00171.
