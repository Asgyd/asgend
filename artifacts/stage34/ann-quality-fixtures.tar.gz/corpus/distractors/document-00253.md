# Evaluation item 00253
Synthetic benchmark source record number 00253.
