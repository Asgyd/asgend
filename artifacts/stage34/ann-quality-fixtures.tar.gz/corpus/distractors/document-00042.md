# Evaluation item 00042
Synthetic benchmark source record number 00042.
