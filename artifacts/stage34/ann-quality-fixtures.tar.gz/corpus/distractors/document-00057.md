# Evaluation item 00057
Synthetic benchmark source record number 00057.
