# Evaluation item 00092
Synthetic benchmark source record number 00092.
