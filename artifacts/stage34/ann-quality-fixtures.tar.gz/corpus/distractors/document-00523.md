# Evaluation item 00523
Synthetic benchmark source record number 00523.
