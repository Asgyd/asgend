# Evaluation item 00288
Synthetic benchmark source record number 00288.
