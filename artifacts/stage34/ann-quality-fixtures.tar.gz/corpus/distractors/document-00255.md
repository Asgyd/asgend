# Evaluation item 00255
Synthetic benchmark source record number 00255.
