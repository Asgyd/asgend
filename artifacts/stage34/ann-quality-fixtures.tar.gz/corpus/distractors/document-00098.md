# Evaluation item 00098
Synthetic benchmark source record number 00098.
