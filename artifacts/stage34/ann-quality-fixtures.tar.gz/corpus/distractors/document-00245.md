# Evaluation item 00245
Synthetic benchmark source record number 00245.
