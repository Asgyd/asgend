# Evaluation item 00327
Synthetic benchmark source record number 00327.
