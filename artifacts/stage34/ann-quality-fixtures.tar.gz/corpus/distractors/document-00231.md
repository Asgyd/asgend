# Evaluation item 00231
Synthetic benchmark source record number 00231.
