# Evaluation item 00073
Synthetic benchmark source record number 00073.
