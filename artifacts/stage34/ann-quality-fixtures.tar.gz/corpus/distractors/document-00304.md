# Evaluation item 00304
Synthetic benchmark source record number 00304.
