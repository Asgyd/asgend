# Evaluation item 00034
Synthetic benchmark source record number 00034.
