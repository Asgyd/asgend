# Evaluation item 00035
Synthetic benchmark source record number 00035.
