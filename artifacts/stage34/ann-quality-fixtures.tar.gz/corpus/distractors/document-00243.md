# Evaluation item 00243
Synthetic benchmark source record number 00243.
