# Evaluation item 00238
Synthetic benchmark source record number 00238.
