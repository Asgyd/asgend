# Evaluation item 00192
Synthetic benchmark source record number 00192.
