# Evaluation item 00123
Synthetic benchmark source record number 00123.
