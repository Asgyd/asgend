# Evaluation item 00038
Synthetic benchmark source record number 00038.
