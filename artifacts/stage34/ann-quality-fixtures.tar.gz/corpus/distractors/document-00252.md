# Evaluation item 00252
Synthetic benchmark source record number 00252.
