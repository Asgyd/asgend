# Evaluation item 00055
Synthetic benchmark source record number 00055.
