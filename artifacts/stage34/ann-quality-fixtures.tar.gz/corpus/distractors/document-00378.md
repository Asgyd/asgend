# Evaluation item 00378
Synthetic benchmark source record number 00378.
