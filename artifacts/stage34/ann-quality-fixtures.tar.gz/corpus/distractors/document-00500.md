# Evaluation item 00500
Synthetic benchmark source record number 00500.
