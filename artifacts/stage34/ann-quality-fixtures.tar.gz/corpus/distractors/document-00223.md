# Evaluation item 00223
Synthetic benchmark source record number 00223.
