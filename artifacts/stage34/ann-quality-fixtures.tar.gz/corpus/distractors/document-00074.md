# Evaluation item 00074
Synthetic benchmark source record number 00074.
