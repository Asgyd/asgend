# Evaluation item 00222
Synthetic benchmark source record number 00222.
