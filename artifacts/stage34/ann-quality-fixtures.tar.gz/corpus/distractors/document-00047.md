# Evaluation item 00047
Synthetic benchmark source record number 00047.
