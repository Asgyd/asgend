# Evaluation item 00474
Synthetic benchmark source record number 00474.
