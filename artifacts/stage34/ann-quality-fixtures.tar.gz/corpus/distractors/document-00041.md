# Evaluation item 00041
Synthetic benchmark source record number 00041.
