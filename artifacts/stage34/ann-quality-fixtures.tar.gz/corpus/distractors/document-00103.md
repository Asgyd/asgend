# Evaluation item 00103
Synthetic benchmark source record number 00103.
