# Evaluation item 00096
Synthetic benchmark source record number 00096.
