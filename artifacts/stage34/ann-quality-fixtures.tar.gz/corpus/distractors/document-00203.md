# Evaluation item 00203
Synthetic benchmark source record number 00203.
