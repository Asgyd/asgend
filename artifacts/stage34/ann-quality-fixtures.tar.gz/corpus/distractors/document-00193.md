# Evaluation item 00193
Synthetic benchmark source record number 00193.
