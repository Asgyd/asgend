# Evaluation item 00066
Synthetic benchmark source record number 00066.
