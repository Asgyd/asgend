# Evaluation item 00173
Synthetic benchmark source record number 00173.
