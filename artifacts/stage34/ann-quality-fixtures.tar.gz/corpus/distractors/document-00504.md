# Evaluation item 00504
Synthetic benchmark source record number 00504.
