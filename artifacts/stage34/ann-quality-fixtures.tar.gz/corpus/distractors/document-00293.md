# Evaluation item 00293
Synthetic benchmark source record number 00293.
