# Evaluation item 00244
Synthetic benchmark source record number 00244.
