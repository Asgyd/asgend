# Evaluation item 00348
Synthetic benchmark source record number 00348.
