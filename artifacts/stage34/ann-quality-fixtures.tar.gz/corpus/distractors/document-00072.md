# Evaluation item 00072
Synthetic benchmark source record number 00072.
