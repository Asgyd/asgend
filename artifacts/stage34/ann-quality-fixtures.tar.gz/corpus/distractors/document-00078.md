# Evaluation item 00078
Synthetic benchmark source record number 00078.
