# Evaluation item 00143
Synthetic benchmark source record number 00143.
