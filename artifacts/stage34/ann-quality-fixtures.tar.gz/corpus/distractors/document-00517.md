# Evaluation item 00517
Synthetic benchmark source record number 00517.
