# Evaluation item 00357
Synthetic benchmark source record number 00357.
