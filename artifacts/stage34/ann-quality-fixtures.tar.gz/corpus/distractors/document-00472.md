# Evaluation item 00472
Synthetic benchmark source record number 00472.
