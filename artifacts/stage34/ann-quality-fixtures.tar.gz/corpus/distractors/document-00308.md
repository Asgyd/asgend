# Evaluation item 00308
Synthetic benchmark source record number 00308.
