# Evaluation item 00052
Synthetic benchmark source record number 00052.
