# Evaluation item 00157
Synthetic benchmark source record number 00157.
