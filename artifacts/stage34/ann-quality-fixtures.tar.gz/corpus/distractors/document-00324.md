# Evaluation item 00324
Synthetic benchmark source record number 00324.
