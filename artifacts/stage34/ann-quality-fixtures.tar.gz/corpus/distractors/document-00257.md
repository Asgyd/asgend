# Evaluation item 00257
Synthetic benchmark source record number 00257.
