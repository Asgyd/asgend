# Evaluation item 00177
Synthetic benchmark source record number 00177.
