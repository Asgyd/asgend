# Evaluation item 00505
Synthetic benchmark source record number 00505.
