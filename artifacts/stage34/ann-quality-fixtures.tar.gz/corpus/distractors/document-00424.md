# Evaluation item 00424
Synthetic benchmark source record number 00424.
