# Evaluation item 00106
Synthetic benchmark source record number 00106.
