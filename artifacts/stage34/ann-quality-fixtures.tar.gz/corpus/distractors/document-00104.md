# Evaluation item 00104
Synthetic benchmark source record number 00104.
