# Evaluation item 00342
Synthetic benchmark source record number 00342.
