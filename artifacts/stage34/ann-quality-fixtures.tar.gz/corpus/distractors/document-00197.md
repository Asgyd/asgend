# Evaluation item 00197
Synthetic benchmark source record number 00197.
