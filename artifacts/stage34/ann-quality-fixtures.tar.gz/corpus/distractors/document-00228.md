# Evaluation item 00228
Synthetic benchmark source record number 00228.
