# Evaluation item 00045
Synthetic benchmark source record number 00045.
