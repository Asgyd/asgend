# Evaluation item 00296
Synthetic benchmark source record number 00296.
