# Evaluation item 00340
Synthetic benchmark source record number 00340.
