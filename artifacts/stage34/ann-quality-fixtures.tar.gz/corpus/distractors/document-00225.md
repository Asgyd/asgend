# Evaluation item 00225
Synthetic benchmark source record number 00225.
