# Evaluation item 00425
Synthetic benchmark source record number 00425.
