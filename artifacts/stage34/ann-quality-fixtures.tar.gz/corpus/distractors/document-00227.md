# Evaluation item 00227
Synthetic benchmark source record number 00227.
