# Evaluation item 00497
Synthetic benchmark source record number 00497.
