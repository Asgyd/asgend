# Evaluation item 00174
Synthetic benchmark source record number 00174.
