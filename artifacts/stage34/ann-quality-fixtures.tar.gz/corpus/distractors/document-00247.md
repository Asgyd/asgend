# Evaluation item 00247
Synthetic benchmark source record number 00247.
