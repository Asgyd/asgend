# Evaluation item 00345
Synthetic benchmark source record number 00345.
