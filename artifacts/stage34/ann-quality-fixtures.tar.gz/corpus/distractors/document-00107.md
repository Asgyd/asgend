# Evaluation item 00107
Synthetic benchmark source record number 00107.
