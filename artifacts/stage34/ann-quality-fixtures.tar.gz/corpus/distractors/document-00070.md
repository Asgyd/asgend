# Evaluation item 00070
Synthetic benchmark source record number 00070.
