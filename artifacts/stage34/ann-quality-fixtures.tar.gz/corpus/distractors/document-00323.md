# Evaluation item 00323
Synthetic benchmark source record number 00323.
