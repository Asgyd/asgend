# Evaluation item 00067
Synthetic benchmark source record number 00067.
