# Evaluation item 00069
Synthetic benchmark source record number 00069.
