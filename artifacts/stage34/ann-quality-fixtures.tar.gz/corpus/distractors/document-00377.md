# Evaluation item 00377
Synthetic benchmark source record number 00377.
