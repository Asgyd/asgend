# Evaluation item 00303
Synthetic benchmark source record number 00303.
