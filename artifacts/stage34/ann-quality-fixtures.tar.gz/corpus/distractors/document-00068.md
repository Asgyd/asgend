# Evaluation item 00068
Synthetic benchmark source record number 00068.
