# Evaluation item 00040
Synthetic benchmark source record number 00040.
