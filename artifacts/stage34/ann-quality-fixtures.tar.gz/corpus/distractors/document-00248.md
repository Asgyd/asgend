# Evaluation item 00248
Synthetic benchmark source record number 00248.
