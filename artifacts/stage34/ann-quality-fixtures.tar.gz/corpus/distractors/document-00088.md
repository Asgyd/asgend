# Evaluation item 00088
Synthetic benchmark source record number 00088.
