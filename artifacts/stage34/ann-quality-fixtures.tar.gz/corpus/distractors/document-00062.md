# Evaluation item 00062
Synthetic benchmark source record number 00062.
