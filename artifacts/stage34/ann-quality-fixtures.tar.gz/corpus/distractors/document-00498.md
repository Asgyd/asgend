# Evaluation item 00498
Synthetic benchmark source record number 00498.
